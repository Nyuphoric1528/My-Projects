This folder contains the PCB of all the parts separately.
